// Live hand detection: MediaPipe Hand Landmarker -> finger states -> sign code -> letter
import { FilesetResolver, HandLandmarker } from 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs';
import { CODE_TO_LETTER, SETTINGS } from './config.js';
import { initScene, setText, setReduced } from './animation.js';

const $ = (id) => document.getElementById(id);
const video = $('video'), overlay = $('overlay'), ctx = overlay.getContext('2d');
const el = { start: $('start'), stop: $('stop'), status: $('status'), statusTxt: $('statusTxt'), letter: $('letter'), codeTxt: $('codeTxt'), prog: $('prog'), out: $('out'), ph: $('ph'), retry: $('retryModel') };
let landmarker = null, stream = null, running = false, text = '', lastVideoTime = -1;
let cand = null, since = 0, locked = false, lostAt = 0;

const setStatus = (msg, kind = '') => { el.statusTxt.textContent = msg; el.status.className = 'chip ' + kind; };
const render = () => { el.out.textContent = text; setText(text); };

// ---------- model loading (with timeout + retry) ----------
async function loadModel() {
  el.retry.hidden = true; el.start.disabled = true; setStatus('Loading hand model...', 'warn');
  try {
    const work = (async () => {
      const files = await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm');
      const opts = (delegate) => ({
        baseOptions: { modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task', delegate },
        runningMode: 'VIDEO', numHands: 1,
        minHandDetectionConfidence: SETTINGS.minConfidence, minHandPresenceConfidence: SETTINGS.minConfidence, minTrackingConfidence: SETTINGS.minConfidence
      });
      try { return await HandLandmarker.createFromOptions(files, opts('GPU')); }
      catch { return await HandLandmarker.createFromOptions(files, opts('CPU')); }
    })();
    const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), SETTINGS.modelTimeoutMs));
    landmarker = await Promise.race([work, timeout]);
    setStatus('Model ready. Press Start Camera.', 'ok'); el.start.disabled = false;
  } catch (e) {
    console.error(e); setStatus('Could not load the hand model. Check your internet.', 'bad'); el.retry.hidden = false;
  }
}
el.retry.onclick = loadModel;

// ---------- finger state detection (uses distances, so it works at any hand size or rotation) ----------
function fingerCode(lm, w, h) {
  const p = lm.map(q => ({ x: q.x * w, y: q.y * h, z: q.z * w }));
  const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, (a.z - b.z) * .5);
  const palm = d(p[0], p[9]) || 1, open = [];
  open[0] = d(p[4], p[17]) > d(p[3], p[17]) * SETTINGS.thumbRatio && d(p[4], p[5]) > SETTINGS.thumbSpread * palm;
  [[8, 6], [12, 10], [16, 14], [20, 18]].forEach(([tip, pip], i) => { open[i + 1] = d(p[tip], p[0]) > d(p[pip], p[0]) * SETTINGS.fingerRatio; });
  const code = open.map((o, i) => o ? i + 1 : '').join('');
  return code || '0';
}

// ---------- stability + duplicate protection ----------
function handle(code, now) {
  if (!code) { // no hand
    if (!lostAt) lostAt = now;
    if (now - lostAt > SETTINGS.lostGraceMs) { cand = null; locked = false; el.prog.style.width = '0'; el.codeTxt.textContent = 'Sign code: -'; el.letter.textContent = '-'; }
    return;
  }
  lostAt = 0;
  const letter = CODE_TO_LETTER[code];
  el.codeTxt.textContent = 'Sign code: ' + (code === '0' ? 'Fist' : code) + (letter ? '' : ' (no letter)');
  el.letter.textContent = letter === ' ' ? 'SPACE' : (letter || '?'); el.letter.style.fontSize = letter === ' ' ? '1rem' : '';
  if (code !== cand) { cand = code; since = now; locked = false; el.prog.style.width = '0'; return; }
  if (!letter || locked) return;
  const p = Math.min((now - since) / SETTINGS.holdMs, 1); el.prog.style.width = p * 100 + '%';
  if (p >= 1) { text += letter; locked = true; render(); } // locked until the sign changes or the hand leaves
}

// ---------- drawing ----------
function draw(lm) {
  ctx.clearRect(0, 0, overlay.width, overlay.height); if (!lm) return;
  ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(120,190,255,.95)';
  for (const { start, end } of HandLandmarker.HAND_CONNECTIONS) {
    ctx.beginPath(); ctx.moveTo(lm[start].x * overlay.width, lm[start].y * overlay.height); ctx.lineTo(lm[end].x * overlay.width, lm[end].y * overlay.height); ctx.stroke();
  }
  lm.forEach((q, i) => { ctx.beginPath(); ctx.arc(q.x * overlay.width, q.y * overlay.height, i === 0 ? 7 : 4.5, 0, 7); ctx.fillStyle = i === 0 ? '#ffd166' : '#fff'; ctx.fill(); });
}

function loop() {
  if (!running) return;
  if (video.readyState >= 2 && video.currentTime !== lastVideoTime) {
    lastVideoTime = video.currentTime; const now = performance.now();
    try {
      const res = landmarker.detectForVideo(video, now);
      const lm = res.landmarks && res.landmarks[0];
      draw(lm);
      if (lm) { setStatus('Hand detected', 'ok'); handle(fingerCode(lm, overlay.width, overlay.height), now); }
      else { setStatus('Show your hand to the camera', 'warn'); handle(null, now); }
    } catch (e) { console.error(e); }
  }
  requestAnimationFrame(loop);
}

// ---------- camera ----------
async function startCamera() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return setStatus('Camera is not supported in this browser (needs HTTPS or localhost).', 'bad');
  el.start.disabled = true; setStatus('Waiting for camera permission...', 'warn');
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: false });
    video.srcObject = stream; await video.play();
    overlay.width = video.videoWidth || 640; overlay.height = video.videoHeight || 480;
    el.ph.hidden = true; el.stop.disabled = false; running = true; lastVideoTime = -1; setStatus('Camera on', 'ok'); loop();
  } catch (e) {
    el.start.disabled = false;
    const m = { NotAllowedError: 'Camera permission was denied. Allow it in your browser settings and try again.', NotFoundError: 'No camera found on this device.', NotReadableError: 'Camera is busy in another app.' }[e.name] || 'Could not start the camera.';
    setStatus(m, 'bad'); SV.toast(m, 'err');
  }
}
function stopCamera() {
  running = false; if (stream) stream.getTracks().forEach(t => t.stop()); stream = null; video.srcObject = null;
  ctx.clearRect(0, 0, overlay.width, overlay.height); el.ph.hidden = false; el.stop.disabled = true; el.start.disabled = !landmarker;
  cand = null; locked = false; el.prog.style.width = '0'; if (landmarker) setStatus('Camera stopped', '');
}
el.start.onclick = startCamera; el.stop.onclick = stopCamera;
addEventListener('pagehide', stopCamera);
document.addEventListener('visibilitychange', () => { if (document.hidden && running) { stopCamera(); SV.toast('Camera stopped because the tab was hidden.'); } });

// ---------- text controls ----------
$('space').onclick = () => { text += ' '; render(); };
$('back').onclick = () => { text = [...text].slice(0, -1).join(''); render(); };
$('clear').onclick = () => { text = ''; render(); };
$('copy').onclick = async () => { try { await navigator.clipboard.writeText(text); SV.toast('Copied!', 'ok'); } catch { SV.toast('Copy failed.', 'err'); } };

// ---------- history (local for guests, database for logged-in users) ----------
let items = JSON.parse(localStorage.getItem('sv_hist') || '[]');
function renderHist() {
  const ul = $('hist'); ul.textContent = '';
  $('histNote').textContent = SV.user ? 'Saved to your account.' : 'Saved on this device only. Log in to keep it on your account.';
  $('delAll').hidden = !(SV.user && items.length);
  if (!items.length) { const li = document.createElement('li'); li.textContent = 'Nothing saved yet.'; ul.append(li); return; }
  items.forEach(it => {
    const li = document.createElement('li'), s = document.createElement('span'); s.textContent = it.text;
    const del = document.createElement('button'); del.className = 'btn ghost sm'; del.textContent = 'Delete';
    del.onclick = async () => {
      try { if (SV.user) await SV.api('/api/history/' + it.id, 'DELETE'); items = items.filter(x => x !== it); if (!SV.user) localStorage.setItem('sv_hist', JSON.stringify(items)); renderHist(); } catch (e) { SV.toast(e.message, 'err'); }
    };
    li.append(s, del); ul.append(li);
  });
}
async function loadHist() {
  if (SV.user) { try { items = (await SV.api('/api/history')).items; } catch { items = []; } }
  else items = JSON.parse(localStorage.getItem('sv_hist') || '[]');
  renderHist();
}
$('save').onclick = async () => {
  const t = text.trim(); if (!t) return SV.toast('Nothing to save yet.');
  try {
    if (SV.user) items.unshift((await SV.api('/api/history', 'POST', { text: t })).item);
    else { items.unshift({ id: Date.now(), text: t }); items = items.slice(0, 30); localStorage.setItem('sv_hist', JSON.stringify(items)); }
    renderHist(); SV.toast('Saved.', 'ok');
  } catch (e) { SV.toast(e.message, 'err'); }
};
$('delAll').onclick = async () => { if (!confirm('Delete all saved history?')) return; try { await SV.api('/api/history', 'DELETE'); items = []; renderHist(); SV.toast('History deleted.'); } catch (e) { SV.toast(e.message, 'err'); } };
document.addEventListener('sv-user', loadHist);

// ---------- reduced motion ----------
const rm = $('rm'); rm.checked = localStorage.getItem('sv_rm') === '1' || matchMedia('(prefers-reduced-motion: reduce)').matches;
const applyRm = () => { setReduced(rm.checked); document.documentElement.classList.toggle('reduce', rm.checked); localStorage.setItem('sv_rm', rm.checked ? '1' : '0'); };
rm.onchange = applyRm;

// ---------- start ----------
initScene($('scene')); applyRm(); render();
SV.ready.then(loadHist);
loadModel().finally(() => SV.hideLoader());
