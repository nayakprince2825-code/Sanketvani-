// AI assistant chat (talks to /api/chat; the Groq key stays on the server)
const msgs = document.getElementById('msgs'), form = document.getElementById('form'), inp = document.getElementById('inp'), send = document.getElementById('send');
const KEY = 'sv_chat';
let hist = [];
try { hist = JSON.parse(localStorage.getItem('sv_chat') || '[]').filter(m => m && typeof m.content === 'string'); } catch { hist = []; }
const WELCOME = 'Namaste! I am the SanketVani assistant. Ask me how to use the detector, what the sign codes are, or how hand tracking works. आप हिंदी में भी पूछ सकते हैं।';
const save = () => localStorage.setItem(KEY, JSON.stringify(hist.slice(-40)));
function add(role, text) {
  const d = document.createElement('div'); d.className = 'm ' + (role === 'user' ? 'u' : 'a'); d.textContent = text;
  msgs.append(d); msgs.scrollTop = msgs.scrollHeight; return d;
}
function render() { msgs.textContent = ''; add('assistant', WELCOME); hist.forEach(m => add(m.role, m.content)); }
function typing(el, text) { // typewriter effect
  return new Promise(res => {
    const fast = document.documentElement.classList.contains('reduce') || matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (fast) { el.textContent = text; return res(); }
    let i = 0; const step = Math.max(1, Math.ceil(text.length / 120));
    const id = setInterval(() => { i += step; el.textContent = text.slice(0, i); msgs.scrollTop = msgs.scrollHeight; if (i >= text.length) { clearInterval(id); res(); } }, 18);
  });
}
async function ask(text) {
  hist.push({ role: 'user', content: text }); add('user', text); save();
  const bubble = add('assistant', ''); bubble.innerHTML = '<span class="dots"><span></span><span></span><span></span></span>';
  send.disabled = true;
  try {
    const d = await SV.api('/api/chat', 'POST', { messages: hist.slice(-10) });
    bubble.textContent = ''; await typing(bubble, d.reply);
    hist.push({ role: 'assistant', content: d.reply }); save();
  } catch (e) { bubble.textContent = e.message; bubble.style.color = 'var(--err)'; hist.pop(); save(); }
  send.disabled = false; inp.focus();
}
form.addEventListener('submit', (e) => { e.preventDefault(); const t = inp.value.trim(); if (!t || send.disabled) return; inp.value = ''; ask(t); });
document.getElementById('clearChat').onclick = () => { hist = []; save(); render(); SV.toast('Chat cleared.'); };
const sg = document.getElementById('sugg');
['How do I use the detector?', 'What is the code for D?', 'SanketVani kaise kaam karta hai?'].forEach(s => {
  const b = document.createElement('button'); b.className = 'btn ghost sm'; b.type = 'button'; b.textContent = s; b.onclick = () => ask(s); sg.append(b);
});
render(); SV.hideLoader();
