// 3D floating glowing text using Three.js (one sprite per letter)
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
let renderer, scene, camera, group, canvas, clock, reduced = false, prevLen = 0, items = [];
const MAX = 14, cache = {};
function tex(ch) {
  if (cache[ch]) return cache[ch];
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'); g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = '800 170px "Segoe UI",Arial,sans-serif';
  g.shadowColor = '#4aa8ff'; g.shadowBlur = 40; g.fillStyle = '#4aa8ff'; g.fillText(ch, 128, 140);
  const gr = g.createLinearGradient(0, 50, 0, 210); gr.addColorStop(0, '#ffffff'); gr.addColorStop(1, '#8cc8ff');
  g.shadowBlur = 12; g.fillStyle = gr; g.fillText(ch, 128, 140);
  return (cache[ch] = new THREE.CanvasTexture(c));
}
export function initScene(el) {
  try {
    canvas = el; renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    scene = new THREE.Scene(); camera = new THREE.PerspectiveCamera(40, 1, .1, 100); camera.position.z = 12;
    group = new THREE.Group(); scene.add(group); clock = new THREE.Clock();
    resize(); addEventListener('resize', resize); renderer.setAnimationLoop(loop); return true;
  } catch (e) { console.warn('3D unavailable, showing plain text only', e); return false; }
}
function resize() {
  if (!renderer) return;
  const w = canvas.clientWidth || 300, h = canvas.clientHeight || 150;
  renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); layout();
}
function layout() {
  if (!group) return;
  const n = items.length, viewW = 2 * 12 * Math.tan(THREE.MathUtils.degToRad(20)) * camera.aspect;
  const sp = 1.7; group.scale.setScalar(Math.min(1, (viewW * .92) / Math.max(1, n * sp)));
  items.forEach((it, i) => { it.sprite.position.x = (i - (n - 1) / 2) * sp; it.baseX = it.sprite.position.x; });
}
export function setReduced(v) { reduced = v; }
export function setText(text) {
  if (!group) return;
  const chars = [...text], start = Math.max(0, chars.length - MAX), now = clock.elapsedTime;
  items.forEach(i => { group.remove(i.sprite); i.sprite.material.dispose(); }); items = [];
  chars.slice(start).forEach((ch, k) => {
    if (ch === ' ') { items.push({ sprite: new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, opacity: 0 })), born: -99, k }); group.add(items.at(-1).sprite); return; }
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex(ch), transparent: true, depthTest: false }));
    group.add(sp); items.push({ sprite: sp, born: (start + k) >= prevLen ? now : -99, k });
  });
  prevLen = chars.length; layout();
}
const back = (x) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
function loop() {
  const t = clock.elapsedTime;
  group.rotation.y = reduced ? 0 : Math.sin(t * .5) * .15;
  items.forEach((it, i) => {
    const s = reduced ? 1 : back(Math.min((t - it.born) / .55, 1));
    it.sprite.scale.set(2.2 * s, 2.2 * s, 1);
    it.sprite.position.y = reduced ? 0 : Math.sin(t * 1.6 + i * .6) * .2;
    it.sprite.position.z = reduced ? 0 : Math.cos(t * 1.2 + i) * .4;
  });
  renderer.render(scene, camera);
}
