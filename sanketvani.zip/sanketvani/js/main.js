// Shared: loader, navigation, theme, toasts, API helper, login/profile dialogs
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const SV = window.SV = { user: null };
  // Theme
  const saved = localStorage.getItem('sv_theme');
  if (saved) document.documentElement.dataset.theme = saved;
  // Toast
  SV.toast = (msg, type = '') => {
    const t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = msg;
    $('#toasts').append(t); setTimeout(() => t.remove(), 3500);
  };
  // API helper (always JSON, always same-origin cookies)
  SV.api = async (url, method = 'GET', body) => {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'SanketVani' }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'Something went wrong.');
    return d;
  };
  // Loader: hides when page is ready, never longer than 6 seconds
  const loader = $('#loader');
  const hideLoader = () => loader && loader.classList.add('hide');
  window.addEventListener('load', () => setTimeout(hideLoader, 400));
  setTimeout(hideLoader, 6000);
  SV.hideLoader = hideLoader;
  // Nav
  const page = location.pathname.split('/').pop() || 'index.html';
  const links = [['/', 'Home', 'index.html'], ['/detector.html', 'Sign Detector', 'detector.html'], ['/assistant.html', 'AI Assistant', 'assistant.html']];
  const nav = $('#nav');
  nav.innerHTML = `<div class="wrap"><a class="logo" href="/"><i>S</i>SanketVani</a>
   <button class="btn ghost sm burger" id="burger" aria-label="Menu" aria-expanded="false">Menu</button>
   <nav class="links" id="links" aria-label="Main">${links.map(l => `<a class="nl ${page === l[2] ? 'on' : ''}" href="${l[0]}">${l[1]}</a>`).join('')}
   <button class="btn ghost sm" id="theme" aria-label="Toggle dark mode">Dark/Light</button><span class="acct" id="acct"></span></nav></div>`;
  $('#burger').onclick = (e) => { const o = $('#links').classList.toggle('open'); e.target.setAttribute('aria-expanded', o); };
  $('#theme').onclick = () => {
    const d = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = d; localStorage.setItem('sv_theme', d);
  };
  // Dialogs
  document.body.insertAdjacentHTML('beforeend', `
  <dialog id="authDlg" aria-label="Account"><form method="dialog" id="authForm">
   <div class="tabs"><button type="button" class="btn sm" id="tabLogin">Login</button><button type="button" class="btn ghost sm" id="tabReg">Create account</button></div>
   <div id="nameRow" hidden><label for="aName">Name</label><input id="aName" type="text" maxlength="50" autocomplete="name"></div>
   <label for="aEmail">Email</label><input id="aEmail" type="email" maxlength="254" autocomplete="email" required>
   <label for="aPass">Password</label><input id="aPass" type="password" maxlength="72" autocomplete="current-password" required>
   <p class="err-msg" id="aErr" role="alert"></p>
   <div class="bar"><button class="btn" id="aGo" type="submit">Login</button><button class="btn ghost" type="button" id="aX">Cancel</button></div></form></dialog>
  <dialog id="profDlg" aria-label="Profile"><h2>Your profile</h2><p id="pInfo"></p><div class="bar"><button class="btn ghost" id="pClose">Close</button></div></dialog>`);
  let mode = 'login';
  const setMode = (m) => {
    mode = m; $('#nameRow').hidden = m !== 'register';
    $('#tabLogin').className = 'btn sm' + (m === 'login' ? '' : ' ghost'); $('#tabReg').className = 'btn sm' + (m === 'register' ? '' : ' ghost');
    $('#aGo').textContent = m === 'login' ? 'Login' : 'Create account';
    $('#aPass').autocomplete = m === 'login' ? 'current-password' : 'new-password'; $('#aErr').textContent = '';
  };
  SV.openAuth = (m) => { setMode(m); $('#authDlg').showModal(); };
  $('#tabLogin').onclick = () => setMode('login'); $('#tabReg').onclick = () => setMode('register'); $('#aX').onclick = () => $('#authDlg').close();
  $('#authForm').addEventListener('submit', async (e) => {
    e.preventDefault(); const btn = $('#aGo'); btn.disabled = true; $('#aErr').textContent = '';
    try {
      const body = { email: $('#aEmail').value, password: $('#aPass').value };
      if (mode === 'register') body.name = $('#aName').value;
      const d = await SV.api(mode === 'login' ? '/api/login' : '/api/register', 'POST', body);
      setUser(d.user); $('#authDlg').close(); $('#aPass').value = ''; SV.toast('Welcome, ' + d.user.name + '!', 'ok');
      document.dispatchEvent(new CustomEvent('sv-user', { detail: d.user }));
    } catch (err) { $('#aErr').textContent = err.message; }
    btn.disabled = false;
  });
  $('#pClose').onclick = () => $('#profDlg').close();
  function setUser(u) {
    SV.user = u; const a = $('#acct'); a.textContent = '';
    const mk = (txt, cls, fn) => { const b = document.createElement('button'); b.className = 'btn sm ' + cls; b.textContent = txt; b.onclick = fn; a.append(b); };
    if (u) {
      mk(u.name.split(' ')[0], 'ghost', () => { $('#pInfo').textContent = `${u.name} (${u.email}). Joined ${new Date(u.created_at + 'Z').toLocaleDateString()}.`; $('#profDlg').showModal(); });
      mk('Logout', 'ghost', async () => { await SV.api('/api/logout', 'POST'); setUser(null); SV.toast('Logged out.'); document.dispatchEvent(new CustomEvent('sv-user', { detail: null })); });
    } else { mk('Login', 'ghost', () => SV.openAuth('login')); mk('Create Account', '', () => SV.openAuth('register')); }
  }
  setUser(null);
  SV.ready = fetch('/api/me').then(r => r.json()).then(d => { setUser(d.user); return d.user; }).catch(() => null);
})();
