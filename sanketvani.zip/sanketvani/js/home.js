// Builds the sign code chart on the home page from the shared config
import { SIGN_CODES } from './config.js';
const t = document.getElementById('chart');
if (t) {
  const e = Object.entries(SIGN_CODES);
  let h = '<tr>';
  for (let i = 0; i < 4; i++) h += '<th>Letter</th><th>Code</th>';
  h += '</tr>';
  for (let i = 0; i < e.length; i += 4) {
    h += '<tr>';
    for (let j = i; j < i + 4; j++) h += e[j] ? `<td><b>${e[j][0] === ' ' ? 'SPACE' : e[j][0]}</b></td><td>${[].concat(e[j][1]).join(' / ')}</td>` : '<td></td><td></td>';
    h += '</tr>';
  }
  t.innerHTML = h;
}
document.getElementById('yr').textContent = new Date().getFullYear();
