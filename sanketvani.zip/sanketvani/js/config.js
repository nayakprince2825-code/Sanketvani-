// Edit this file to change gestures. Fingers: 1 thumb, 2 index, 3 middle, 4 ring, 5 pinky.
// A code lists the OPEN fingers. 'Fist' means no fingers open. Use an array for several codes.
export const SIGN_CODES = {
  A: '1', B: '2', C: '5', D: '12', E: '123', F: '1234', G: '12345', H: '2345', I: '345',
  J: '45', K: '15', L: '23', M: ['34', '134'], N: '234', O: 'Fist', P: '25', Q: '35',
  R: '13', S: '4', T: '135', U: '1345', V: '1245', W: '24', X: '14', Y: '124', Z: '1235',
  ' ': '125' // SPACE
};
// Tuning knobs (change these if detection feels too strict or too loose)
export const SETTINGS = {
  holdMs: 800,        // how long a sign must stay steady before a letter is added
  lostGraceMs: 300,   // short tracking drop-outs are ignored
  fingerRatio: 1.08,  // finger is open if tip is this much farther from wrist than its middle joint
  thumbRatio: 1.12,   // thumb openness (tip vs joint distance to pinky base)
  thumbSpread: 0.55,  // thumb tip must be this far (x palm size) from index base
  minConfidence: 0.6, // MediaPipe detection confidence
  modelTimeoutMs: 25000
};
// Reverse lookup used by the detector: finger code -> letter
export const CODE_TO_LETTER = {};
for (const [letter, codes] of Object.entries(SIGN_CODES))
  for (const c of [].concat(codes)) CODE_TO_LETTER[c === 'Fist' ? '0' : c] = letter;
