require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const db = require('./db');

const { JWT_SECRET, GROQ_API_KEY, PORT = 3000, NODE_ENV } = process.env;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('\n[SanketVani] Set JWT_SECRET (32+ random characters) in .env\n');
  process.exit(1);
}
const app = express();
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", 'https://cdn.jsdelivr.net', "'wasm-unsafe-eval'"],
    connectSrc: ["'self'", 'https://cdn.jsdelivr.net', 'https://storage.googleapis.com'],
    imgSrc: ["'self'", 'data:', 'blob:'],
    mediaSrc: ["'self'", 'blob:'],
    workerSrc: ["'self'", 'blob:'],
    styleSrc: ["'self'", "'unsafe-inline'"],
    upgradeInsecureRequests: null
  } },
  crossOriginEmbedderPolicy: false
}));
app.use((req, res, next) => { res.setHeader('Permissions-Policy', 'camera=(self), microphone=()'); next(); });
app.use(express.json({ limit: '20kb' }));
app.use(cookieParser());
app.use('/api/', rateLimit({ windowMs: 60_000, max: 120 }));
const authLimit = rateLimit({ windowMs: 15 * 60_000, max: 20, message: { error: 'Too many attempts. Try again later.' } });
const chatLimit = rateLimit({ windowMs: 60_000, max: 15, message: { error: 'Slow down a little and try again.' } });

// Reject non-JSON writes (basic CSRF defence together with SameSite=strict cookies)
app.use('/api/', (req, res, next) => {
  if (['POST', 'PUT', 'DELETE'].includes(req.method) && req.headers['x-requested-with'] !== 'SanketVani')
    return res.status(403).json({ error: 'Invalid request.' });
  next();
});

const DUMMY_HASH = bcrypt.hashSync('dummy-password', 12);
const cookieOpts = { httpOnly: true, sameSite: 'strict', secure: NODE_ENV === 'production', maxAge: 7 * 24 * 3600 * 1000 };
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, created_at: u.created_at });
const setSession = (res, id) => res.cookie('sv_token', jwt.sign({ uid: id }, JWT_SECRET, { expiresIn: '7d' }), cookieOpts);

function auth(req, res, next) {
  try {
    const { uid } = jwt.verify(req.cookies.sv_token, JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(uid);
    if (!user) throw new Error('no user');
    req.user = user; next();
  } catch { res.status(401).json({ error: 'Please log in.' }); }
}

const str = (v, min, max) => typeof v === 'string' && v.trim().length >= min && v.length <= max;

app.post('/api/register', authLimit, (req, res) => {
  const { name, email, password } = req.body || {};
  if (!str(name, 2, 50)) return res.status(400).json({ error: 'Name must be 2-50 characters.' });
  if (!str(email, 5, 254) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email.' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 72 || !/[A-Za-z]/.test(password) || !/\d/.test(password))
    return res.status(400).json({ error: 'Password needs 8-72 characters with a letter and a number.' });
  const mail = email.trim().toLowerCase();
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(mail)) return res.status(409).json({ error: 'That email is already registered.' });
  const info = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)').run(name.trim(), mail, bcrypt.hashSync(password, 12));
  setSession(res, info.lastInsertRowid);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid)) });
});

app.post('/api/login', authLimit, (req, res) => {
  const { email, password } = req.body || {};
  if (!str(email, 3, 254) || typeof password !== 'string' || password.length > 72) return res.status(400).json({ error: 'Enter your email and password.' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.trim().toLowerCase());
  const ok = bcrypt.compareSync(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: 'Wrong email or password.' });
  setSession(res, user.id);
  res.json({ user: publicUser(user) });
});

app.post('/api/logout', (req, res) => { res.clearCookie('sv_token', cookieOpts); res.json({ ok: true }); });

app.get('/api/me', (req, res) => {
  try {
    const { uid } = jwt.verify(req.cookies.sv_token, JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(uid);
    res.json({ user: user ? publicUser(user) : null });
  } catch { res.json({ user: null }); }
});

app.get('/api/history', auth, (req, res) => {
  res.json({ items: db.prepare('SELECT id, text, created_at FROM history WHERE user_id = ? ORDER BY id DESC LIMIT 100').all(req.user.id) });
});
app.post('/api/history', auth, (req, res) => {
  const { text } = req.body || {};
  if (!str(text, 1, 500)) return res.status(400).json({ error: 'Text must be 1-500 characters.' });
  const info = db.prepare('INSERT INTO history (user_id, text) VALUES (?, ?)').run(req.user.id, text.trim());
  res.json({ item: db.prepare('SELECT id, text, created_at FROM history WHERE id = ?').get(info.lastInsertRowid) });
});
app.delete('/api/history/:id', auth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Bad id.' });
  db.prepare('DELETE FROM history WHERE id = ? AND user_id = ?').run(id, req.user.id);
  res.json({ ok: true });
});
app.delete('/api/history', auth, (req, res) => {
  db.prepare('DELETE FROM history WHERE user_id = ?').run(req.user.id);
  res.json({ ok: true });
});

const SYSTEM_PROMPT = `You are the SanketVani assistant. SanketVani is a web app that turns hand signs into text using the webcam and MediaPipe hand tracking (21 landmarks), processed locally in the browser; video is never uploaded.
Sign codes use finger numbers: 1=thumb, 2=index, 3=middle, 4=ring, 5=pinky. A=1 B=2 C=5 D=12 E=123 F=1234 G=12345 H=2345 I=345 J=45 K=15 L=23 M=34 or 134 N=234 O=fist P=25 Q=35 R=13 S=4 T=135 U=1345 V=1245 W=24 X=14 Y=124 Z=1235 SPACE=125.
How to use: open Sign Detector, press Start Camera, allow permission, show your palm to the camera in good light, hold a sign steady for about a second to add a letter. Lower your hand or change sign between double letters. Accuracy depends on lighting and can be tuned in js/config.js.
Reply in the user's language (Hindi or English; Hinglish is fine). Be friendly, concise and beginner-friendly. If unsure, say so. Do not claim recognition is perfect.`;

app.post('/api/chat', chatLimit, async (req, res) => {
  if (!GROQ_API_KEY || GROQ_API_KEY === 'CHANGE_ME') return res.status(503).json({ error: 'The assistant is not configured yet. Add GROQ_API_KEY to .env.' });
  const msgs = Array.isArray(req.body && req.body.messages) ? req.body.messages.slice(-12) : [];
  const clean = msgs.filter(m => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string' && m.content.length > 0 && m.content.length <= 1000)
    .map(m => ({ role: m.role, content: m.content }));
  if (!clean.length || clean[clean.length - 1].role !== 'user') return res.status(400).json({ error: 'Send a message first.' });
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 25_000);
    const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${GROQ_API_KEY}` },
      body: JSON.stringify({ model: 'llama-3.3-70b-versatile', temperature: 0.5, max_tokens: 500, messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...clean] }),
      signal: ctrl.signal
    });
    clearTimeout(timer);
    if (!r.ok) { console.error('Groq error', r.status); return res.status(502).json({ error: 'The AI service had a problem. Try again.' }); }
    const data = await r.json();
    res.json({ reply: (data.choices && data.choices[0] && data.choices[0].message.content) || 'Sorry, I have no answer for that.' });
  } catch (e) {
    console.error('Chat failed:', e.name);
    res.status(502).json({ error: 'Could not reach the AI service. Try again.' });
  }
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
// Serve ONLY public files (never server.js, .env or the database)
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
const page = (f) => (req, res) => res.sendFile(path.join(__dirname, f));
app.get(['/', '/index.html'], page('index.html'));
app.get('/detector.html', page('detector.html'));
app.get('/assistant.html', page('assistant.html'));
app.use((req, res) => res.status(404).send('Not found'));
app.listen(PORT, () => console.log(`SanketVani running at http://localhost:${PORT}`));
